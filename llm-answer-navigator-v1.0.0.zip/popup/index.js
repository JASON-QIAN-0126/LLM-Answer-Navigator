// src/popup/index.ts
console.log("Popup loaded");
